CREATE PROCEDURE QueryBooksAndPress()
  BEGIN
	#Routine body goes here...
	select * from Books; 
	SELECT * FROM presses WHERE id = 3;
END;
