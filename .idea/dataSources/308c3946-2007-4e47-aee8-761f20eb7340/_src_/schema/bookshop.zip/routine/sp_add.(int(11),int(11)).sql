CREATE PROCEDURE sp_add(IN a INT, IN b INT, OUT c INT)
  begin 
set c=a+ b;
end;
