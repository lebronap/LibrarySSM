CREATE PROCEDURE sp_add2(IN a INT, IN b INT, INOUT c INT)
  BEGIN
	#Routine body goes here...
	set c = a + b;
END;
